# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'launcher_3x_getNewGroup.ui'
#
# Created: Thu Sep 20 12:38:30 2012
#      by: PyQt4 UI code generator 4.9.2
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    _fromUtf8 = lambda s: s

class Ui_getNewGroup(object):
    def setupUi(self, getNewGroup):
        getNewGroup.setObjectName(_fromUtf8("getNewGroup"))
        getNewGroup.resize(188, 381)
        getNewGroup.setMaximumSize(QtCore.QSize(188, 16777215))
        self.gridLayout = QtGui.QGridLayout(getNewGroup)
        self.gridLayout.setObjectName(_fromUtf8("gridLayout"))
        self.button_cancel = QtGui.QPushButton(getNewGroup)
        self.button_cancel.setObjectName(_fromUtf8("button_cancel"))
        self.gridLayout.addWidget(self.button_cancel, 2, 2, 1, 1)
        self.button_ok = QtGui.QPushButton(getNewGroup)
        self.button_ok.setObjectName(_fromUtf8("button_ok"))
        self.gridLayout.addWidget(self.button_ok, 2, 1, 1, 1)
        self.label = QtGui.QLabel(getNewGroup)
        self.label.setObjectName(_fromUtf8("label"))
        self.gridLayout.addWidget(self.label, 0, 0, 1, 3)
        spacerItem = QtGui.QSpacerItem(40, 20, QtGui.QSizePolicy.Expanding, QtGui.QSizePolicy.Minimum)
        self.gridLayout.addItem(spacerItem, 2, 0, 1, 1)
        self.treeWidget_groups = QtGui.QTreeWidget(getNewGroup)
        self.treeWidget_groups.setObjectName(_fromUtf8("treeWidget_groups"))
        font = QtGui.QFont()
        font.setFamily(_fromUtf8("Ubuntu"))
        font.setPointSize(10)
        self.treeWidget_groups.headerItem().setFont(0, font)
        self.gridLayout.addWidget(self.treeWidget_groups, 1, 0, 1, 3)

        self.retranslateUi(getNewGroup)
        QtCore.QMetaObject.connectSlotsByName(getNewGroup)
        getNewGroup.setTabOrder(self.button_ok, self.button_cancel)

    def retranslateUi(self, getNewGroup):
        getNewGroup.setWindowTitle(QtGui.QApplication.translate("getNewGroup", "Copy to Group", None, QtGui.QApplication.UnicodeUTF8))
        self.button_cancel.setText(QtGui.QApplication.translate("getNewGroup", "Cancel", None, QtGui.QApplication.UnicodeUTF8))
        self.button_ok.setText(QtGui.QApplication.translate("getNewGroup", "Copy", None, QtGui.QApplication.UnicodeUTF8))
        self.label.setText(QtGui.QApplication.translate("getNewGroup", "<html><head/><body><p><span style=\" font-size:10pt;\">Which group am I copying to?</span></p></body></html>", None, QtGui.QApplication.UnicodeUTF8))
        self.treeWidget_groups.headerItem().setText(0, QtGui.QApplication.translate("getNewGroup", "Groups", None, QtGui.QApplication.UnicodeUTF8))


class getNewGroup(QtGui.QWidget, Ui_getNewGroup):
    def __init__(self, parent=None, f=QtCore.Qt.WindowFlags()):
        QtGui.QWidget.__init__(self, parent, f)

        self.setupUi(self)

