# -*- coding: utf-8 -*-

from sqlite3 import Cursor, connect
from re import split
from launcher_3x_resource import schema, get_tables

class DbCursor(Cursor):
    """Hold the database open for R/W"""
    def __init__(self, db_):
        self.db_gate = connect(db_)
        Cursor.__init__(self, self.db_gate)

    def build(self):
        cmds = split(r';', schema.decode('base64', 'strict').strip())
        for line in range(len(cmds) - 1):
            self.execute(cmds[line].strip())

    def getTable(self, table_name):
        cmd = 'SELECT * FROM "%s"' % table_name
        self.execute(cmd)
        return self.fetchall()

    def getApps(self, groupID):
        cmd = get_tables.decode('base64', 'strict') % groupID
        self.execute(cmd)
        return self.fetchall()

    def getAllApps(self):
        cmd = 'SELECT * FROM "item"'
        self.execute(cmd)
        return self.fetchall()

    def findApp(self, path):
        cmd = 'SELECT iditem FROM "item" WHERE "path" == "%s"' % path
        self.execute(cmd)
        return self.fetchall()

    def add_group(self, index, name, seq, date):
        cmd = 'INSERT INTO "itemgroup" VALUES ("%s","%s","%s","%s")' % (index, name, seq, date)
        self.execute(cmd)

    def add_app(self, index, name, path, date):
        cmd = 'INSERT INTO "item" VALUES ("%s","%s","%s","%s")' % (index, name, path, date)
        self.execute(cmd)

    def add_app_link(self, appID, groupID, seqInGroup):
        cmd = 'INSERT INTO "itemgroup_has_item" VALUES ("%s","%s","%s")' % (appID, groupID, seqInGroup)
        self.execute(cmd)

    def deleteAllRows(self, table_name):
        cmd = 'DELETE FROM %s' % table_name
        self.execute(cmd)

    def deleteGroup(self, groupID):
        cmd = 'DELETE FROM "itemgroup" WHERE "iditemgroup" = "%s"' % groupID
        self.execute(cmd)

    def deleteGroupLink(self, groupID):
        cmd = 'DELETE FROM "itemgroup_has_item" WHERE "itemgroup_iditemgroup" = "%s"' % groupID
        self.execute(cmd)

    def deleteSingleAppLink(self, groupID, itemID):
        cmd = 'DELETE FROM "itemgroup_has_item" WHERE "itemgroup_iditemgroup"="%s" AND "item_iditem" = "%s"' % (groupID, itemID)
        self.execute(cmd)

    def deleteAllAppLinks(self, appID):
        cmd = 'DELETE FROM "itemgroup_has_item" WHERE "item_iditem" = "%s"' % appID
        self.execute(cmd)

    def deleteApp(self, appID):
        cmd = 'DELETE FROM "item" WHERE "iditem" = "%s"' % appID
        self.execute(cmd)

    def renameApp(self, app_name, appID):
        cmd = 'UPDATE "item" SET "name"="%s" WHERE "iditem"="%s"' % (app_name, appID)
        self.execute(cmd)

    def renameGroup(self, group_name, groupID):
        cmd = 'UPDATE "itemgroup" SET "name"="%s" WHERE "iditemgroup"="%s"' % (group_name, groupID)
        self.execute(cmd)

    def changePath(self, path_name, appID):
        cmd = 'UPDATE "item" SET "path"="%s" WHERE "iditem"="%s"' % (path_name, appID)
        self.execute(cmd)

    def commit(self):
        self.db_gate.commit()

    def shutdown(self):
        self.db_gate.commit()
        self.close()
